#ifndef _STM32_DEF_BUILD_
#define _STM32_DEF_BUILD_
#define CMSIS_STARTUP_FILE "startup_stm32l476xx.s"
#endif /* _STM32_DEF_BUILD_ */
