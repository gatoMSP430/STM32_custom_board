/*
 * Copyright(c) 2019 Xilinx Ltd.
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef PLATFORM_INFO_H_
#define PLATFORM_INFO_H_

struct remoteproc * app_init(unsigned int cpu_id);
#endif /* PLATFORM_INFO_H_ */
