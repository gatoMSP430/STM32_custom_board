/*
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef RPMSG_ECHO_H
#define RPMSG_ECHO_H

#define RPMSG_SERVICE_NAME         "rpmsg-openamp-demo-channel"

#endif /* RPMSG_ECHO_H */
